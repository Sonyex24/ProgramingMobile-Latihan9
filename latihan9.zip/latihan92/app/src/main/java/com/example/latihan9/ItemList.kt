package com.example.latihan9

class ItemList (
    var judul: String,
    var subjudul: String,
    var imageURL: String

)
