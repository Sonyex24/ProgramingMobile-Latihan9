package com.example.latihan9;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

class MainActivity : AppCompatActivity() {
    private lateinit var binding: AdapterList
    override fun onCreate (savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main)
        val recyclerView = findViewById<RecyclerView>(R.id.recycler_view)
            recyclerView.layoutManager = LinearLayoutManager(this)
        //recyclerView.layoutManager = GridLayoutManager(this, 3)
        recyclerView.setHasFixedSize(true)
        val itemList = listOf(
            ItemList("Judul 1", "Deskripsi 1",
                "https://maukuliah.ap-south-1.linodeobjects.com/gallery/071008/Gedung%204%20UNNAR-thumbnail.jpg"),
            ItemList("Judul 2", "Deskripsi 2",
                "https://maukuliah.ap-south-1.linodeobjects.com/gallery/051005/1704701136-dRuDtaHKCE-thumbnail.jpg"),
            ItemList("Judul 3", "Deskripsi 3",
                "https://maukuliah.ap-south-1.linodeobjects.com/gallery/011057/1704946027-mee53wl4Gc-thumbnail.jpg")

        )
        val adapter = AdapterList(itemList)
        recyclerView.adapter = adapter
    }
}